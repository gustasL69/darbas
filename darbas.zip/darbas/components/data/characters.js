  const characters = [
    { id: 1, title: "Hero", name: "Hero", age: 25, job: "Warrior", img: "src/images/hero.jpg" },
    { id: 2, title: "Mage", name: "Mage", age: 70, job: "Wizard", img: "src/images/mage.jpg" },
    { id: 3, title: "Robot", name: "Robot", age: 5, job: "Helper Bot", img: "src/images/robot.jpg" },
    { id: 4, title: "Archer", name: "Archer", age: 32, job: "Ranger", img: "src/images/archer.jpg" },
    { id: 5, title: "Healer", name: "Healer", age: 28, job: "Cleric", img: "src/images/healer.jpg" },
    { id: 6, title: "Soldier", name: "Soldier", age: 40, job: "Fighter", img: "src/images/soldier.jpg" },
  ];

  export default characters;