import "./Header.css"

const Header = ()=>{
    return (
    <>
        <h1>Character Catalog</h1>
    </>
    );
};

export default Header;